# Case Study: Canadian Cheese Directory

# 1. Introduction

In this case study will be analysis Canadian cheeses made from cow, goat, sheep, or buffalo milk. Canada produces more than 1450 cheeses that are listed in the Canadian Cheese Directory. 

The several varieties of cheese have been established according to guidelines including the type of milk, the cheese category, the milk treatment, the fat content, the ripening period and the production method. 

## 1.1 Objective

# 2. Data

## 2.1 Source

The Canadian Cheese Directory dataset was compiled by the Canadian Dairy Information Centre (CDIC) in collaboration with the Ministère de l'Agriculture, des Pêcheries et de l'Alimentation du Québec (MAPAQ). 

For further analysis, the dataset can be on Kaggle:  https://www.kaggle.com/datasets/noahjanes/canadian-cheese-directory?resource=download

Contains information licensed under the Open Government Licence – Canada.

## 2.1 Atributes

This directory offers detailed insights into various cheeses based on essential attributes, including:

- Milk Type: Cow, goat, sheep, or buffalo
- Cheese Category: Fresh, soft, semi-soft, hard, and others
- Milk Treatment: Raw vs. pasteurized
- Fat Content: Varying fat percentages that influence flavor and texture
- Ripening Period: Aging processes ranging from days to years
- Production Method: Artisanal or industrial production

# 3. Ask

Based on the dataset these are the question I would like to explore:
1. What is the distribution of cheeses by milk type (cow, goat, sheep, buffalo)?
2. How does the ripening period affect the fat content and category of cheeses?
3. What are the top provinces in terms of cheese variety and production?
4. How does milk treatment (raw vs. pasteurized) impact the cheese category and ripening period?
5. What is the relationship between fat content and production methods (e.g., artisanal vs. industrial)?

# 4. Process 

## 4.1 Importing Libraries


```python
import pandas as pd
import numpy as np
```

## 4.2 Importing Data


```python
# STEP 1: COLLECT DATA
df = pd.read_csv('/Users/noahscomputer/Downloads/cheese_data.csv')
```

## 4.3 Print the first 5 entries


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CheeseId</th>
      <th>ManufacturerProvCode</th>
      <th>ManufacturingTypeEn</th>
      <th>MoisturePercent</th>
      <th>FlavourEn</th>
      <th>CharacteristicsEn</th>
      <th>Organic</th>
      <th>CategoryTypeEn</th>
      <th>MilkTypeEn</th>
      <th>MilkTreatmentTypeEn</th>
      <th>RindTypeEn</th>
      <th>CheeseName</th>
      <th>FatLevel</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>228</td>
      <td>NB</td>
      <td>Farmstead</td>
      <td>47.0</td>
      <td>Sharp, lactic</td>
      <td>Uncooked</td>
      <td>0</td>
      <td>Firm Cheese</td>
      <td>Ewe</td>
      <td>Raw Milk</td>
      <td>Washed Rind</td>
      <td>Sieur de Duplessis (Le)</td>
      <td>lower fat</td>
    </tr>
    <tr>
      <th>1</th>
      <td>242</td>
      <td>NB</td>
      <td>Farmstead</td>
      <td>47.9</td>
      <td>Sharp, lactic, lightly caramelized</td>
      <td>Uncooked</td>
      <td>0</td>
      <td>Semi-soft Cheese</td>
      <td>Cow</td>
      <td>Raw Milk</td>
      <td>Washed Rind</td>
      <td>Tomme Le Champ Doré</td>
      <td>lower fat</td>
    </tr>
    <tr>
      <th>2</th>
      <td>301</td>
      <td>ON</td>
      <td>Industrial</td>
      <td>54.0</td>
      <td>Mild, tangy, and fruity</td>
      <td>Pressed and cooked cheese, pasta filata, inter...</td>
      <td>0</td>
      <td>Firm Cheese</td>
      <td>Cow</td>
      <td>Pasteurized</td>
      <td>NaN</td>
      <td>Provolone Sette Fette (Tre-Stelle)</td>
      <td>lower fat</td>
    </tr>
    <tr>
      <th>3</th>
      <td>303</td>
      <td>NB</td>
      <td>Farmstead</td>
      <td>47.0</td>
      <td>Sharp with fruity notes and a hint of wild honey</td>
      <td>NaN</td>
      <td>0</td>
      <td>Veined Cheeses</td>
      <td>Cow</td>
      <td>Raw Milk</td>
      <td>NaN</td>
      <td>Geai Bleu (Le)</td>
      <td>lower fat</td>
    </tr>
    <tr>
      <th>4</th>
      <td>319</td>
      <td>NB</td>
      <td>Farmstead</td>
      <td>49.4</td>
      <td>Softer taste</td>
      <td>NaN</td>
      <td>1</td>
      <td>Semi-soft Cheese</td>
      <td>Cow</td>
      <td>Raw Milk</td>
      <td>Washed Rind</td>
      <td>Gamin (Le)</td>
      <td>lower fat</td>
    </tr>
  </tbody>
</table>
</div>



## 4.4 Print the last 5 entries


```python
df.tail(1)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CheeseId</th>
      <th>ManufacturerProvCode</th>
      <th>ManufacturingTypeEn</th>
      <th>MoisturePercent</th>
      <th>FlavourEn</th>
      <th>CharacteristicsEn</th>
      <th>Organic</th>
      <th>CategoryTypeEn</th>
      <th>MilkTypeEn</th>
      <th>MilkTreatmentTypeEn</th>
      <th>RindTypeEn</th>
      <th>CheeseName</th>
      <th>FatLevel</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1041</th>
      <td>2391</td>
      <td>AB</td>
      <td>Artisan</td>
      <td>31.5</td>
      <td>Available in different flavor: original, herb ...</td>
      <td>Soft Squeaky Fresh Cheese.</td>
      <td>0</td>
      <td>Fresh Cheese</td>
      <td>Cow</td>
      <td>Pasteurized</td>
      <td>No Rind</td>
      <td>Super Fresh Cheese Curds</td>
      <td>higher fat</td>
    </tr>
  </tbody>
</table>
</div>



## 4.5 Rename headers of the dataframe


```python
# Rename to make them consistent
headers = [ 'cheese_id', 
    'province_code', 
    'manufacturing_type', 
    'moisture_percent', 
    'flavour', 
    'characteristics', 
    'is_organic', 
    'category', 
    'milk_type', 
    'milk_treatment', 
    'rind_type', 
    'cheese_name', 
    'fat_level']
```


```python
df.columns = headers
```


```python
#Check Used the head()to displayed the first 3 columns of the data frame

df.head(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>cheese_id</th>
      <th>province_code</th>
      <th>manufacturing_type</th>
      <th>moisture_percent</th>
      <th>flavour</th>
      <th>characteristics</th>
      <th>is_organic</th>
      <th>category</th>
      <th>milk_type</th>
      <th>milk_treatment</th>
      <th>rind_type</th>
      <th>cheese_name</th>
      <th>fat_level</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>228</td>
      <td>NB</td>
      <td>Farmstead</td>
      <td>47.0</td>
      <td>Sharp, lactic</td>
      <td>Uncooked</td>
      <td>0</td>
      <td>Firm Cheese</td>
      <td>Ewe</td>
      <td>Raw Milk</td>
      <td>Washed Rind</td>
      <td>Sieur de Duplessis (Le)</td>
      <td>lower fat</td>
    </tr>
    <tr>
      <th>1</th>
      <td>242</td>
      <td>NB</td>
      <td>Farmstead</td>
      <td>47.9</td>
      <td>Sharp, lactic, lightly caramelized</td>
      <td>Uncooked</td>
      <td>0</td>
      <td>Semi-soft Cheese</td>
      <td>Cow</td>
      <td>Raw Milk</td>
      <td>Washed Rind</td>
      <td>Tomme Le Champ Doré</td>
      <td>lower fat</td>
    </tr>
    <tr>
      <th>2</th>
      <td>301</td>
      <td>ON</td>
      <td>Industrial</td>
      <td>54.0</td>
      <td>Mild, tangy, and fruity</td>
      <td>Pressed and cooked cheese, pasta filata, inter...</td>
      <td>0</td>
      <td>Firm Cheese</td>
      <td>Cow</td>
      <td>Pasteurized</td>
      <td>NaN</td>
      <td>Provolone Sette Fette (Tre-Stelle)</td>
      <td>lower fat</td>
    </tr>
  </tbody>
</table>
</div>



## 4.6 Identify the data types of the dataframe columns


```python
df.dtypes
```




    cheese_id               int64
    province_code          object
    manufacturing_type     object
    moisture_percent      float64
    flavour                object
    characteristics        object
    is_organic              int64
    category               object
    milk_type              object
    milk_treatment         object
    rind_type              object
    cheese_name            object
    fat_level              object
    dtype: object



## 4.7 Identify the statistical description of the dataset, including that of 'object' data types.


```python
df.describe(include='all')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>cheese_id</th>
      <th>province_code</th>
      <th>manufacturing_type</th>
      <th>moisture_percent</th>
      <th>flavour</th>
      <th>characteristics</th>
      <th>is_organic</th>
      <th>category</th>
      <th>milk_type</th>
      <th>milk_treatment</th>
      <th>rind_type</th>
      <th>cheese_name</th>
      <th>fat_level</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1042.000000</td>
      <td>1042</td>
      <td>1042</td>
      <td>1028.000000</td>
      <td>801</td>
      <td>643</td>
      <td>1042.000000</td>
      <td>1019</td>
      <td>1041</td>
      <td>977</td>
      <td>721</td>
      <td>1042</td>
      <td>1042</td>
    </tr>
    <tr>
      <th>unique</th>
      <td>NaN</td>
      <td>10</td>
      <td>3</td>
      <td>NaN</td>
      <td>635</td>
      <td>535</td>
      <td>NaN</td>
      <td>6</td>
      <td>8</td>
      <td>3</td>
      <td>4</td>
      <td>1038</td>
      <td>2</td>
    </tr>
    <tr>
      <th>top</th>
      <td>NaN</td>
      <td>QC</td>
      <td>Industrial</td>
      <td>NaN</td>
      <td>Mild</td>
      <td>Creamy</td>
      <td>NaN</td>
      <td>Firm Cheese</td>
      <td>Cow</td>
      <td>Pasteurized</td>
      <td>No Rind</td>
      <td>Ménestrel (Le)</td>
      <td>lower fat</td>
    </tr>
    <tr>
      <th>freq</th>
      <td>NaN</td>
      <td>796</td>
      <td>455</td>
      <td>NaN</td>
      <td>59</td>
      <td>19</td>
      <td>NaN</td>
      <td>349</td>
      <td>743</td>
      <td>800</td>
      <td>404</td>
      <td>2</td>
      <td>684</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>1560.633397</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>47.069747</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.095010</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>std</th>
      <td>451.811164</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9.592647</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.293369</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>min</th>
      <td>228.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>12.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>1280.250000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>40.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>1548.500000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>46.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>1901.750000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>52.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>max</th>
      <td>2391.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>92.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>



## 4.8 Identify the summary information of the dataset


```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1042 entries, 0 to 1041
    Data columns (total 13 columns):
     #   Column              Non-Null Count  Dtype  
    ---  ------              --------------  -----  
     0   cheese_id           1042 non-null   int64  
     1   province_code       1042 non-null   object 
     2   manufacturing_type  1042 non-null   object 
     3   moisture_percent    1028 non-null   float64
     4   flavour             801 non-null    object 
     5   characteristics     643 non-null    object 
     6   is_organic          1042 non-null   int64  
     7   category            1019 non-null   object 
     8   milk_type           1041 non-null   object 
     9   milk_treatment      977 non-null    object 
     10  rind_type           721 non-null    object 
     11  cheese_name         1042 non-null   object 
     12  fat_level           1042 non-null   object 
    dtypes: float64(1), int64(2), object(10)
    memory usage: 106.0+ KB



```python
df.shape
```




    (1042, 13)



## 4.9 Identify missing values

### 4.9.1 Replace '?' with 'NaN'


```python
df.replace('?', np.nan, inplace = True)
df.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>cheese_id</th>
      <th>province_code</th>
      <th>manufacturing_type</th>
      <th>moisture_percent</th>
      <th>flavour</th>
      <th>characteristics</th>
      <th>is_organic</th>
      <th>category</th>
      <th>milk_type</th>
      <th>milk_treatment</th>
      <th>rind_type</th>
      <th>cheese_name</th>
      <th>fat_level</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>228</td>
      <td>NB</td>
      <td>Farmstead</td>
      <td>47.0</td>
      <td>Sharp, lactic</td>
      <td>Uncooked</td>
      <td>0</td>
      <td>Firm Cheese</td>
      <td>Ewe</td>
      <td>Raw Milk</td>
      <td>Washed Rind</td>
      <td>Sieur de Duplessis (Le)</td>
      <td>lower fat</td>
    </tr>
    <tr>
      <th>1</th>
      <td>242</td>
      <td>NB</td>
      <td>Farmstead</td>
      <td>47.9</td>
      <td>Sharp, lactic, lightly caramelized</td>
      <td>Uncooked</td>
      <td>0</td>
      <td>Semi-soft Cheese</td>
      <td>Cow</td>
      <td>Raw Milk</td>
      <td>Washed Rind</td>
      <td>Tomme Le Champ Doré</td>
      <td>lower fat</td>
    </tr>
    <tr>
      <th>2</th>
      <td>301</td>
      <td>ON</td>
      <td>Industrial</td>
      <td>54.0</td>
      <td>Mild, tangy, and fruity</td>
      <td>Pressed and cooked cheese, pasta filata, inter...</td>
      <td>0</td>
      <td>Firm Cheese</td>
      <td>Cow</td>
      <td>Pasteurized</td>
      <td>NaN</td>
      <td>Provolone Sette Fette (Tre-Stelle)</td>
      <td>lower fat</td>
    </tr>
    <tr>
      <th>3</th>
      <td>303</td>
      <td>NB</td>
      <td>Farmstead</td>
      <td>47.0</td>
      <td>Sharp with fruity notes and a hint of wild honey</td>
      <td>NaN</td>
      <td>0</td>
      <td>Veined Cheeses</td>
      <td>Cow</td>
      <td>Raw Milk</td>
      <td>NaN</td>
      <td>Geai Bleu (Le)</td>
      <td>lower fat</td>
    </tr>
    <tr>
      <th>4</th>
      <td>319</td>
      <td>NB</td>
      <td>Farmstead</td>
      <td>49.4</td>
      <td>Softer taste</td>
      <td>NaN</td>
      <td>1</td>
      <td>Semi-soft Cheese</td>
      <td>Cow</td>
      <td>Raw Milk</td>
      <td>Washed Rind</td>
      <td>Gamin (Le)</td>
      <td>lower fat</td>
    </tr>
  </tbody>
</table>
</div>



### 4.9.2 Count missing values in each column


```python
df.isnull().sum()
```




    cheese_id               0
    province_code           0
    manufacturing_type      0
    moisture_percent       14
    flavour               241
    characteristics       399
    is_organic              0
    category               23
    milk_type               1
    milk_treatment         65
    rind_type             321
    cheese_name             0
    fat_level               0
    dtype: int64



Based on the summary above, each column has 1042 rows of data and seven of the columns containing missing data:

    "moisture_percent": 14 missing data
    "flavour":  241 missing data
    "characteristics": 399 missing data
    "category": 23 missing data
    "milk_type": 1 missing data
    "milk_treatment": 65 missing data
    "rind_type": 321 missing data
    



## 4.10 Deal with missing data 

### 4.10.1 Replace it by mean


```python
moisture_mean = df['moisture_percent'].mean()
```


```python
df['moisture_percent'].replace(np.nan, moisture_mean, inplace = True )
```

### 4.10.2 Replace it by other


```python
df['flavour'].replace(np.nan, 'unknown', inplace = True)
```


```python
df['characteristics'].replace(np.nan, 'Not Specified', inplace = True)
```

### 4.10.3 Replace it by mode


```python
df['category'].mode()
```




    0    Firm Cheese
    Name: category, dtype: object




```python
df['category'].replace(np.nan,'Firm Cheese', inplace = True )
```


```python
df['milk_type'].value_counts()
```




    Cow                  743
    Goat                 214
    Ewe                   62
    Cow and Goat          13
    Ewe and Cow            4
    Ewe and Goat           2
    Buffalo Cow            2
    Cow, Goat and Ewe      1
    Name: milk_type, dtype: int64




```python
df['milk_type'].replace(np.nan,'Cow', inplace = True )
```


```python
df['milk_treatment'].value_counts()
```




    Pasteurized    800
    Raw Milk       115
    Thermised       62
    Name: milk_treatment, dtype: int64




```python
df['milk_treatment'].replace(np.nan, 'Pasteurized', inplace = True)
```


```python
df['rind_type'].value_counts()
```




    No Rind         404
    Bloomy Rind     164
    Washed Rind     148
    Brushed Rind      5
    Name: rind_type, dtype: int64




```python
df['rind_type'].replace(np.nan, 'No Rind', inplace = True)
```

### 4.10.4 Re-Check if we hava missing values


```python
df.isnull().sum()
```




    cheese_id             0
    province_code         0
    manufacturing_type    0
    moisture_percent      0
    flavour               0
    characteristics       0
    is_organic            0
    category              0
    milk_type             0
    milk_treatment        0
    rind_type             0
    cheese_name           0
    fat_level             0
    dtype: int64



### 4.10.5 Check for duplicated values.


```python
df.duplicated().sum()
```




    0



## 4.11 Correct data format


```python
df.dtypes
```




    cheese_id               int64
    province_code          object
    manufacturing_type     object
    moisture_percent      float64
    flavour                object
    characteristics        object
    is_organic              int64
    category               object
    milk_type              object
    milk_treatment         object
    rind_type              object
    cheese_name            object
    fat_level              object
    dtype: object



### 4.11.1 Verify if the dataframe includes negative entries 


```python
df[df['moisture_percent'] < 0].count()
```




    cheese_id             0
    province_code         0
    manufacturing_type    0
    moisture_percent      0
    flavour               0
    characteristics       0
    is_organic            0
    category              0
    milk_type             0
    milk_treatment        0
    rind_type             0
    cheese_name           0
    fat_level             0
    dtype: int64




```python
df.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>cheese_id</th>
      <th>province_code</th>
      <th>manufacturing_type</th>
      <th>moisture_percent</th>
      <th>flavour</th>
      <th>characteristics</th>
      <th>is_organic</th>
      <th>category</th>
      <th>milk_type</th>
      <th>milk_treatment</th>
      <th>rind_type</th>
      <th>cheese_name</th>
      <th>fat_level</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>228</td>
      <td>NB</td>
      <td>Farmstead</td>
      <td>47.0</td>
      <td>Sharp, lactic</td>
      <td>Uncooked</td>
      <td>0</td>
      <td>Firm Cheese</td>
      <td>Ewe</td>
      <td>Raw Milk</td>
      <td>Washed Rind</td>
      <td>Sieur de Duplessis (Le)</td>
      <td>lower fat</td>
    </tr>
    <tr>
      <th>1</th>
      <td>242</td>
      <td>NB</td>
      <td>Farmstead</td>
      <td>47.9</td>
      <td>Sharp, lactic, lightly caramelized</td>
      <td>Uncooked</td>
      <td>0</td>
      <td>Semi-soft Cheese</td>
      <td>Cow</td>
      <td>Raw Milk</td>
      <td>Washed Rind</td>
      <td>Tomme Le Champ Doré</td>
      <td>lower fat</td>
    </tr>
    <tr>
      <th>2</th>
      <td>301</td>
      <td>ON</td>
      <td>Industrial</td>
      <td>54.0</td>
      <td>Mild, tangy, and fruity</td>
      <td>Pressed and cooked cheese, pasta filata, inter...</td>
      <td>0</td>
      <td>Firm Cheese</td>
      <td>Cow</td>
      <td>Pasteurized</td>
      <td>No Rind</td>
      <td>Provolone Sette Fette (Tre-Stelle)</td>
      <td>lower fat</td>
    </tr>
    <tr>
      <th>3</th>
      <td>303</td>
      <td>NB</td>
      <td>Farmstead</td>
      <td>47.0</td>
      <td>Sharp with fruity notes and a hint of wild honey</td>
      <td>Not Specified</td>
      <td>0</td>
      <td>Veined Cheeses</td>
      <td>Cow</td>
      <td>Raw Milk</td>
      <td>No Rind</td>
      <td>Geai Bleu (Le)</td>
      <td>lower fat</td>
    </tr>
    <tr>
      <th>4</th>
      <td>319</td>
      <td>NB</td>
      <td>Farmstead</td>
      <td>49.4</td>
      <td>Softer taste</td>
      <td>Not Specified</td>
      <td>1</td>
      <td>Semi-soft Cheese</td>
      <td>Cow</td>
      <td>Raw Milk</td>
      <td>Washed Rind</td>
      <td>Gamin (Le)</td>
      <td>lower fat</td>
    </tr>
  </tbody>
</table>
</div>



# 4.12 Exploratory Data Analysis (EDA) with visualization

Create visualizations to answer the questions:
1. What is the distribution of cheeses by milk type (cow, goat, sheep, buffalo)?
2. What is the distribution of different cheese categories (e.g., soft, hard, semi-soft) across various milk types (cow, goat, sheep, buffalo)?
3. How does milk treatment (raw vs. pasteurized) impact the cheese category?
4. What is the relationship between fat content and production methods (e.g., artisanal vs. industrial)?
5. What are the top provinces in terms of cheese variety and production?
    


```python
import numpy as np
import pandas as pd

import seaborn as sns
import matplotlib.pyplot as plt
```

#### Question 1
Based on the barplot, what is the distribution of cheeses by milk type (cow, goat, sheep, buffalo)?


```python
milk_type_group = df.groupby('milk_type', as_index = False).agg({'cheese_id': 'count'})
```


```python
plt.figure(figsize=(12, 6))
sns.barplot(data = milk_type_group, x = 'milk_type', y = 'cheese_id')
plt.title('Distribution of Cheeses by Milk Type', fontsize=20)
plt.xlabel('Milk Type', fontsize=14)
plt.ylabel('Count', fontsize=14)
#plt.xticks(rotation=45)
plt.show()
```


    
![png](output_67_0.png)
    


#### Answer

Cow milk is the most common, the second most is goat.

### Sub-question
What is the distribution of different cheese categories (e.g., soft, hard, semi-soft) across various milk types (cow, goat, sheep, buffalo)?


```python
plt.figure(figsize=(16, 6))

# Sample groupby operation to get the counts
category_distribution = df.groupby(['milk_type', 'category'], as_index=False).agg({'cheese_id': 'count'})

# Pivot the data so each 'category' is a column and 'milk_type' is the index
category_distribution = category_distribution.pivot(index='milk_type', columns='category', values='cheese_id')

# Plot a stacked bar chart
category_distribution.plot(kind='bar', stacked=True, figsize=(10, 6))

```




    <AxesSubplot:xlabel='milk_type'>




    <Figure size 1152x432 with 0 Axes>



    
![png](output_71_2.png)
    


### Answer

Cow milk dominates the production of many cheese type; firm cheese, soft cheese and semi-soft cheese are mostly made from cow milk. Goat milk is mostly used to produce soft cheese, fresh cheese and firm cheese. Ewe(sheep) milk is moslty used to produce semi-soft cheese and fresh cheese in smaller quantities. 

#### Question 2
How does the average fat content differ between artisanal and industrial cheeses, and how does milk type influence these trends?


```python
manufacturing_distribution = df.groupby(['milk_type','manufacturing_type'] , as_index= False).agg({'cheese_id': 'count'})
```


```python
plt.figure(figsize=(16, 6))
sns.barplot(data = manufacturing_distribution, x = 'milk_type', y= 'cheese_id', hue = 'manufacturing_type' )
```




    <AxesSubplot:xlabel='milk_type', ylabel='cheese_id'>




    
![png](output_76_1.png)
    


The majority of cheeses come from cow milk, with the majority being industrial. Artisan and farmstead production are also present with small numbers. The production of got cheeses are balanced between artisan, farmstead  and industrial manufacturing. Other milk types are less common, with few artisan and industial production, but moslty rare. 

### Which type of cheese has the highest fat


```python
manufacturing_distribution = df.groupby(['milk_type','fat_level'] , as_index= False).agg({'cheese_id': 'count'})
```


```python
plt.figure(figsize=(16, 6))
sns.barplot(data = manufacturing_distribution, x = 'milk_type', y= 'cheese_id', hue = 'fat_level' )
```




    <AxesSubplot:xlabel='milk_type', ylabel='cheese_id'>




    
![png](output_80_1.png)
    


The above bar chart shows that cow milk cheese is greater in quantity with it's cheese having lower fat content compared to than other milk type. But it also has higher fat content other milk type. Also, goat cheese seems to have lower fat content. 

### Subquestion: milk_type'vs 'milk_treatment'


```python
grop = df.groupby(['milk_type','milk_treatment'] , as_index = False).agg({'cheese_id': 'count'})
plt.figure(figsize=(16, 6))
sns.barplot(data = grop, x = 'milk_type', y= 'cheese_id', hue = 'milk_treatment' )
```




    <AxesSubplot:xlabel='milk_type', ylabel='cheese_id'>




    
![png](output_83_1.png)
    


The most common treatment for cow milk is Pasteurized treatment. The large majority of cow milk is being pasteurized. Same with goat milk. 

## What impact does milk treatment (raw vs. pasteurized) have on cheese category ?


```python
grop = df.groupby(['milk_treatment','category'] , as_index = False).agg({'cheese_id': 'count'})
```


```python
plt.figure(figsize=(16, 6))
sns.barplot(data = grop, x = 'milk_treatment', y= 'cheese_id', hue = 'category' )
```




    <AxesSubplot:xlabel='milk_treatment', ylabel='cheese_id'>




    
![png](output_87_1.png)
    


### Subquestion:  milk_treatment' vs 'manufacturing_typ


```python
manufacturing_distribution = df.groupby(['milk_treatment','manufacturing_type'] , as_index= False).agg({'cheese_id': 'count'})
plt.figure(figsize=(16, 6))
sns.barplot(data = manufacturing_distribution, x = 'milk_treatment', y= 'cheese_id', hue = 'manufacturing_type' )
```




    <AxesSubplot:xlabel='milk_treatment', ylabel='cheese_id'>




    
![png](output_89_1.png)
    


Most of the cheese are produced with pasteurized milk which are mainly manufacture by industrial. Artisan manufacturing is frequent in pasteurized, raw milk and thermised milk categories. Farmstead cheeses are mostly produced using pasteurized milk. 

### What impact does milk treatment (raw vs. pasteurized) have on fat content?


```python
fat_group = df.groupby(['milk_treatment','fat_level'], as_index = False).agg({'cheese_id': 'count'})
```


```python
plt.figure(figsize=(16, 6))
sns.barplot(data =fat_group, x = 'milk_treatment', y= 'cheese_id', hue = 'fat_level' , palette="coolwarm")
```




    <AxesSubplot:xlabel='milk_treatment', ylabel='cheese_id'>




    
![png](output_93_1.png)
    


Pasteurized milk dominates in both higher fat (blue) and lower fat (peach) cheese production. However, there’s a clear trend showing that more cheeses fall into the lower fat category. 

# What is the relationship between fat content and production methods (e.g., artisanal vs. industrial)?


```python
fattss_group = df.groupby(['manufacturing_type','fat_level'], as_index = False).agg({'cheese_id': 'count'})
plt.figure(figsize=(16, 6))
sns.barplot(data =fattss_group, x = 'manufacturing_type', y= 'cheese_id', hue = 'fat_level' )
```




    <AxesSubplot:xlabel='manufacturing_type', ylabel='cheese_id'>




    
![png](output_96_1.png)
    


### Cheeses made from raw milk  are more likely to have  higher fat, while pasteurixed milk is more likely associated with lower-fat cheeses

# How is organic cheese distributed across different fat level?


```python
fattss_group = df.groupby(['fat_level','is_organic'], as_index = False).agg({'cheese_id': 'count'})
```


```python
plt.figure(figsize=(16, 6))
sns.barplot(data =fattss_group, x = 'is_organic', y= 'cheese_id', hue = 'fat_level' )
```




    <AxesSubplot:xlabel='is_organic', ylabel='cheese_id'>




    
![png](output_100_1.png)
    


## 3. What are the top provinces in terms of cheese variety and production?


```python
is_organic_countt = df.groupby(['province_code','milk_type'] , as_index= False).agg({'cheese_id': 'count'})
```


```python
plt.figure(figsize=(16, 6))

sns.barplot(data = is_organic_countt, x ='milk_type', y = 'cheese_id', hue='province_code' )

```




    <AxesSubplot:xlabel='milk_type', ylabel='cheese_id'>




    
![png](output_103_1.png)
    


 Quebec(QC) is the top producer of cow , goat and Ewe milk in Canada. Ontario is the second largest producer. 

### Question 3
What is the distribution of organic versus non-organic cheeses within each milk type?


```python
is_organic_count = df.groupby(['milk_type','is_organic'] , as_index= False).agg({'cheese_id': 'count'})
```


```python
plt.figure(figsize=(16, 6))

sns.barplot(data = is_organic_count, x ='milk_type', y = 'cheese_id', hue='is_organic' )

```




    <AxesSubplot:xlabel='milk_type', ylabel='cheese_id'>




    
![png](output_107_1.png)
    


Most cow milk is non-organic, which isn’t surprising since it usually goes through pasteurization a process to kill off bacteria and keep it fresh longer. 

# Conclusion 

The majority of milk weather be coming from cow, goat, ewe(sheep) is being  pasteurized, which reflects the fouses on safety and the complian with food regulations. Raw milk cheese is the second most common, it might be link to the production of artoisanal industries. 

Pasteurized milk is likely preferred for mass production, given its longer shelf life and safety for large-scale distribution. Industrial processes align with these needs, explaining the dominance.

## Recomendations

Mass producers should continue to develop low-fat pasteurized products to meet growing health trends but might consider premium versions that retain flavor.


```python

```
